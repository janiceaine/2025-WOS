using AlbumsApiCrud.Models;
using Microsoft.AspNetCore.Mvc;

namespace AlbumsApiCrud.Controllers;

[ApiController]
[Route("api/albums")]
public class AlbumsController : ControllerBase
{
    private readonly AlbumContext _context;

    public AlbumsController(AlbumContext context)
    {
        _context = context;
    }

    // Getting all albums
    [HttpGet("")]
    public ActionResult<List<Album>> GetAllAlbums()
    {
        var albums = _context.Albums.ToList();
        if (albums.Count == 0)
        {
            return NotFound("No Albums Found");
        }
        return Ok(_context.Albums);
    }

    // Getting a single album by ID
    [HttpGet("{id}")]
    public ActionResult<Album> GetOneAlbum(int id)
    {
        var theAlbum = _context.Albums.Where(album => album.Id == id).FirstOrDefault();
        if (theAlbum is null)
        {
            return NotFound("No Album was Found.");
        }
        return Ok();
    }

    // Creating a new album
    [HttpPost("")]
    public ActionResult<List<Album>> CreateAlbum([FromBody] Album newAlbum)
    {
        _context.Albums.Add(newAlbum);
        _context.SaveChanges();

        _context.Albums.Add(newAlbum);
        return CreatedAtAction(nameof(GetOneAlbum), new { id = newAlbum.Id }, newAlbum);
    }

    // Updating an album by ID
    [HttpPut("{id}")]
    public IActionResult UpdateAlbum(int id, [FromBody] Album updatedAlbum)
    {
        if (id != updatedAlbum.Id)
        {
            return BadRequest("Album ID in the URL does not match the ID in the request body.");
        }

        var maybeAlbum = _context.Albums.FirstOrDefault(album => album.Id == id);
        if (maybeAlbum is null)
        {
            return NotFound("Album not Found.");
        }

        // updating the properties
        maybeAlbum.Rank = updatedAlbum.Rank;
        maybeAlbum.Artist = updatedAlbum.Artist;
        maybeAlbum.ReleaseYear = updatedAlbum.ReleaseYear;
        maybeAlbum.Genre = updatedAlbum.Genre;
        maybeAlbum.AlbumTitle = updatedAlbum.AlbumTitle;

        _context.SaveChanges();
        return NoContent();
    }

    // Deleting an album
    [HttpDelete("{id}")]
    public IActionResult DeleteAlbum(int id)
    {
        var albumToRemove = _context.Albums.FirstOrDefault(album => album.Id == id);

        if (albumToRemove is null)
        {
            return NotFound("No Album Found.");
        }

        _context.Albums.Remove(albumToRemove);
        return NoContent();
    }

    // Filter albums by Genre(Query String)
    [HttpGet("filter")]
    public ActionResult FilterAlbum(string genre)
    {
        var query = _context.Albums.AsQueryable();

        if (!string.IsNullOrEmpty(genre))
        {
            query = query.Where(album =>
                album.Genre.Contains(genre, StringComparison.OrdinalIgnoreCase)
            );
        }
        var filteredAlbums = query.ToList();
        if (filteredAlbums.Count == 0)
        {
            return NotFound("No Albums Found matching this search criteria.");
        }
        return Ok(filteredAlbums);
    }

    // Search Albums by Artist or Title(Query
    [HttpGet("search")]
    public ActionResult SearchAlbum(string term)
    {
        var query = _context.Albums.AsQueryable();

        if (string.IsNullOrEmpty(term))
        {
            query = query.Where(album =>
                album.Artist.Contains(term, StringComparison.OrdinalIgnoreCase)
                || album.AlbumTitle.Contains(term, StringComparison.OrdinalIgnoreCase)
            );
        }

        var foundAlbums = query.ToList();

        if (foundAlbums.Count == 0)
        {
            return NotFound("No Artists or Album Titles found matching the search criteria.");
        }
        return Ok(foundAlbums);
    }
}
