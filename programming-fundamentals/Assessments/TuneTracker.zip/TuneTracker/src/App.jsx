import TuneTracker from './components/TuneTracker';

function App() {
  return (
    <div>
      
      <div className="bg-success mb-3">
        <h2 className="container p-3">
          <i className="bi bi-boombox me-2"></i>
          TuneTracker</h2>
      </div>

      <div className="container">
        
        <TuneTracker />
      </div>



    </div>
  )
}
export default App