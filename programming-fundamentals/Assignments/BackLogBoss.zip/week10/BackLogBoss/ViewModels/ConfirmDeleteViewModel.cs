namespace BackLogBoss.ViewModels;

public class ConfirmDeleteViewModel
{
    public int Id { get; set; }
    public string Title { get; set; } = string.Empty;
}
