import BirdDataList from "./components/BirdDataList"

function App() {
  return (
    
    <div className="container mt-3 bg-body">
      <h1>BirdWatch Pro</h1>
        <BirdDataList />
    </div>
  )
}

export default App

// Collaborated with Ms. Janis