console.log("Connected!");

let heading = document.querySelector('h1');
console.log(heading);


let paragraphs = document.querySelectorAll('p');
console.log(paragraphs);


let selectButton = document.querySelector('#contact-button');
console.log(selectButton);


function countparagraphs () {
    let count = 0;
    for (p of paragraphs) {
        count++;
    }
    return count;
}
console.log('Number of paragraphs:', countparagraphs());


function paragraphsText() {
    let allParagraphText = '';
    for (p of paragraphs) {
        allParagraphText += p.innerText + ' ';
    }
    return allParagraphText.trim();
}
console.log('All paragraph text:', paragraphsText());


function classElemHighlight() {
    let elements = [];
    let classElements = document.querySelectorAll('.highlight');
    for (let elem of classElements) {
        elements.push(elem);
    }
    return elements;
}
console.log('Elements with class "highlight":', classElemHighlight());



let firstSelectElem = document.querySelector('section');
console.log(firstSelectElem);

let AllSelectElem = document.querySelectorAll('section');
console.log(AllSelectElem);

console.log('The first section element returns only the first section elements while the second section element returns all section elements.');


let spanDIvs = document.querySelectorAll("div span");
console.log(spanDIvs);


let directChild = document.querySelector('nav > ul'); 
console.log(directChild);


let adjacentSibling = document.querySelector('p + button');
console.log(adjacentSibling.innerText);


let generalSiblings = document.querySelectorAll('h2 ~ p');
console.log(generalSiblings);


let mixedSelectors = document.querySelector('aside section p.highlight');
console.log(mixedSelectors);

let chainSelectors = document.querySelectorAll('aside .note');
chainSelectors.forEach(chainSelector => {
    console.log(chainSelector.innerText);
});