import Header from './components/Header';
import ProfileCard from './components/ProfileCard';
import Sidebar from './components/Sidebar';
import Footer from './components/Footer';
import '/style.css';

function App() {
  return (
    <>
    <div className="App">
      
      <Header className="header"/>

      <main className="main-content" >
        <ProfileCard className="container"/>
        <Sidebar className="container"/>
      </main>
      <Footer className="footer"/>
    </div>
    </>
  )
}

export default App;