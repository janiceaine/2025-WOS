function Footer() {
  return (
    <footer >
        <p className="container">Meowspace 2025</p>
    </footer>
  )
}

export default Footer;