function Header() {
  return (
    <header>
      <h4 className="container">
        <strong>Sir Pounce-a-Lot</strong>
      </h4>
    </header>
  );
}

export default Header;
