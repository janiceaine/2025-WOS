Using this points system from the lesson today:

Points system:
- id: 100 pts
- class: 10 pts
- element: 1 pt

    1. div p (1 + 1 = 2) // element + element

    2. #main .highlight (1 0 0 + 1 0 = 110)  // id + class

    3. ul > li a (1  + 1 = 3) // element +  element + element

    4. article h2 + p (1 + 1 + 1 = 3) // element + element + element

    5. nav#site-nav ul li.active a (1 + 1 0 0 +  1 + 1  + 1 0 + 1 = 114) // element + id + element + element + class + element

    6. section#hero .intro .cta-button (1 + 1 0 0 +  1 0 + 1 0 = 121) // element + id + class + class

    7. body.homepage header nav > ul li:first-child a (1 + 1 0 +  1 + 1 +  1 + 1 + 1 0 + 1 = 26) // element + class + element + element + element + element + class + element

// worked with Janis
